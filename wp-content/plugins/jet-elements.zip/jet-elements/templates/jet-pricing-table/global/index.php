<?php
/**
 * Pricing table main template
 */

$settings      = $this->get_settings_for_display();
$icon_position = ! empty( $settings['icon_position'] ) ? $settings['icon_position'] : 'inside';
?>
<div class="pricing-table <?php $this->_html( 'featured', 'featured-table' ); ?>">
	<?php if ( 'inside' === $icon_position ) {
		$this->_glob_inc_if( 'heading', array( $this->_new_icon_prefix . 'icon', 'icon', 'title', 'subtitle' ) );
	} else {
		$this->_icon( 'icon', '<div class="pricing-table__icon"><div class="pricing-table__icon-box"><span class="jet-elements-icon">%s</span></div></div>' );
		$this->_glob_inc_if( 'heading', array( 'title', 'subtitle' ) );
	} ?>
	<?php $this->_glob_inc_if( 'price', array( 'price_prefix', 'price', 'price_suffix' ) ); ?>
	<?php $this->_get_global_looped_template( 'features', 'features_list' ); ?>
	<?php $this->_glob_inc_if( 'action', array( 'button_before', 'button_url', 'button_text', 'button_after' ) ); ?>
	<?php $this->_glob_inc_if( 'badge', array( 'featured' ) ); ?>
</div>
