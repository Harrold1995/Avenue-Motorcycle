<?php
/**
 * Dropbar content template
 */
?>
<div class="jet-dropbar__content-wrapper">
	<div class="jet-dropbar__content"><?php
		echo $this->get_dropbar_content();
	?></div>
</div>